# Simulated Configuration File
class Config:
    # Simulated sensitive configuration
    SECRET_KEY = 'super_secret_airport_system_key_do_not_share!'
    DATABASE_URI = 'postgresql://admin:hardcoded_db_password@internal-db.udaan.local/flight_management'
    INTERNAL_API_TOKEN = 'UDAAN_INTERNAL_ACCESS_TOKEN_XYZ'
    DEBUG_MODE = False
    
    # Simulated server paths
    UPLOAD_FOLDER = '/var/www/udaan/uploads/'
    LOG_FILE_PATH = '/var/log/udaan/access.log'

# Additional sensitive information
ADMIN_CREDENTIALS = {
    'username': 'airport_admin',
    'password': 'UdaanSecureAccess2024!'
}