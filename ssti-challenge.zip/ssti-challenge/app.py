from flask import Flask, render_template, request
import os

app = Flask(__name__)

# Dummy flight database
FLIGHTS = {
    'john_doe': {
        'flight_number': 'UA123',
        'destination': 'New Delhi',
        'status': 'On Time'
    },
    'jane_smith': {
        'flight_number': 'UA456',
        'destination': 'Mumbai',
        'status': 'Delayed'
    }
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/flight_status', methods=['POST'])
def flight_status():
    username = request.form.get('username', '')
    
    # VULNERABLE: Directly rendering user input in template
    return render_template('flight_status.html', username=username, flight=FLIGHTS.get(username, None))

if __name__ == '__main__':
    # WARNING: Never use debug=True in production
    app.run(debug=True, host='0.0.0.0', port=5000)